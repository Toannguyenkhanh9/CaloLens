// FILE: src/i18n/caloLensOnboardingTranslations.ts
import i18n from './index';

const en = {
  caloLensOnboarding: {
    brandCaption: 'AI nutrition companion',
    chooseLanguage: 'Choose language',
    languageSubtitle:
      'The app language changes immediately and is saved for next time.',
    kicker: 'PERSONAL SETUP',
    step1Title: 'About you',
    step1Subtitle:
      'Basic details help personalize your daily nutrition target.',
    step2Title: 'Body measurements',
    step2Subtitle:
      'Height and weight are used to estimate calories and BMI.',
    step3Title: 'Choose your goal',
    step3Subtitle:
      'Your goal changes the calorie and macro guidance shown in CaloLens.',
    namePlaceholder: 'How should we call you?',
    agePlaceholder: 'e.g. 28',
    healthNote: 'Health note',
    optional: 'Optional',
    healthPlaceholder:
      'Anything that may affect your nutrition plan',
    localNote:
      'Your profile is stored locally on this device.',
    measurementTitle:
      'Used for your daily targets',
    measurementBody:
      'CaloLens uses these measurements to estimate calories, macros and BMI.',
    injuryHint:
      'This note helps keep recommendations in context.',
    injuryPlaceholder:
      'Briefly describe the injury',
    tipTitle:
      'You can change this later',
    tipBody:
      'Update your profile or calorie target at any time from Settings.',
    finish: 'Create my plan',
    readyKicker: 'YOUR PLAN IS READY',
    readyTitle: 'Welcome to CaloLens',
    readySubtitle:
      'Your calorie and nutrition guidance can now be calculated from this profile.',
    estimated: 'Estimated',
    startingGuidance:
      'Starting guidance',
    disclaimer:
      'BMI and nutrition targets are estimates for general wellness and are not medical advice.',
    startTracking: 'Start tracking',
    adviceIntro:
      'Your estimated BMI is {{bmi}} ({{label}}).',
    adviceUnder:
      'A gradual calorie surplus with enough protein may support healthy weight gain.',
    adviceNormal:
      'Focus on consistent meals, protein, fiber and hydration.',
    adviceOver:
      'A moderate calorie deficit and regular meal tracking may support fat loss.',
    adviceObese:
      'Start with realistic nutrition changes and consider professional guidance.',
    goalAdviceLose:
      'CaloLens will prioritize a controlled calorie deficit and adequate protein.',
    goalAdviceMuscle:
      'CaloLens will emphasize protein and enough calories to support muscle growth.',
    goalAdviceMaintain:
      'CaloLens will aim for stable calories and balanced macros.',
    goalAdviceRecomp:
      'CaloLens will emphasize protein and a controlled calorie target for body recomposition.',
    goalAdviceEndurance:
      'CaloLens will keep sufficient carbohydrates and hydration in your daily plan.',
    goalAdviceWellness:
      'CaloLens will focus on balanced nutrition that supports recovery and daily movement.',
    adviceInjury:
      'Nutrition guidance does not replace medical advice for an injury.',
  },
};

const vi = {
  caloLensOnboarding: {
    brandCaption: 'Trợ lý dinh dưỡng AI',
    chooseLanguage: 'Chọn ngôn ngữ',
    languageSubtitle:
      'Ngôn ngữ được đổi ngay và lưu lại cho lần mở tiếp theo.',
    kicker: 'THIẾT LẬP CÁ NHÂN',
    step1Title: 'Thông tin của bạn',
    step1Subtitle:
      'Thông tin cơ bản giúp cá nhân hóa mục tiêu dinh dưỡng hằng ngày.',
    step2Title: 'Số đo cơ thể',
    step2Subtitle:
      'Chiều cao và cân nặng được dùng để ước tính calo và BMI.',
    step3Title: 'Chọn mục tiêu',
    step3Subtitle:
      'Mục tiêu sẽ thay đổi hướng dẫn calo và macro trong CaloLens.',
    namePlaceholder: 'Bạn muốn được gọi là gì?',
    agePlaceholder: 'Ví dụ: 28',
    healthNote: 'Ghi chú sức khỏe',
    optional: 'Không bắt buộc',
    healthPlaceholder:
      'Thông tin có thể ảnh hưởng đến kế hoạch dinh dưỡng',
    localNote:
      'Hồ sơ được lưu cục bộ trên thiết bị này.',
    measurementTitle:
      'Dùng để tính mục tiêu hằng ngày',
    measurementBody:
      'CaloLens dùng số đo để ước tính calo, macro và BMI.',
    injuryHint:
      'Ghi chú này giúp đặt lời khuyên trong đúng bối cảnh.',
    injuryPlaceholder:
      'Mô tả ngắn gọn chấn thương',
    tipTitle:
      'Bạn có thể thay đổi sau',
    tipBody:
      'Cập nhật hồ sơ hoặc mục tiêu calo bất kỳ lúc nào trong Cài đặt.',
    finish: 'Tạo kế hoạch',
    readyKicker:
      'KẾ HOẠCH ĐÃ SẴN SÀNG',
    readyTitle:
      'Chào mừng đến CaloLens',
    readySubtitle:
      'CaloLens có thể tính hướng dẫn calo và dinh dưỡng từ hồ sơ này.',
    estimated: 'Ước tính',
    startingGuidance:
      'Hướng dẫn ban đầu',
    disclaimer:
      'BMI và mục tiêu dinh dưỡng chỉ là ước tính tham khảo, không phải tư vấn y tế.',
    startTracking:
      'Bắt đầu theo dõi',
    adviceIntro:
      'BMI ước tính của bạn là {{bmi}} ({{label}}).',
    adviceUnder:
      'Tăng calo từ từ và bổ sung đủ protein có thể hỗ trợ tăng cân lành mạnh.',
    adviceNormal:
      'Ưu tiên bữa ăn đều đặn, đủ protein, chất xơ và nước.',
    adviceOver:
      'Thâm hụt calo vừa phải và ghi bữa ăn đều đặn có thể hỗ trợ giảm mỡ.',
    adviceObese:
      'Bắt đầu với thay đổi dinh dưỡng thực tế và cân nhắc tư vấn chuyên môn.',
    goalAdviceLose:
      'CaloLens sẽ ưu tiên thâm hụt calo có kiểm soát và đủ protein.',
    goalAdviceMuscle:
      'CaloLens sẽ ưu tiên protein và đủ năng lượng để hỗ trợ tăng cơ.',
    goalAdviceMaintain:
      'CaloLens sẽ hướng đến calo ổn định và macro cân bằng.',
    goalAdviceRecomp:
      'CaloLens sẽ ưu tiên protein và mục tiêu calo phù hợp để tái cấu trúc cơ thể.',
    goalAdviceEndurance:
      'CaloLens sẽ duy trì đủ carbohydrate và nước trong kế hoạch hằng ngày.',
    goalAdviceWellness:
      'CaloLens sẽ tập trung vào dinh dưỡng cân bằng để hỗ trợ phục hồi và vận động.',
    adviceInjury:
      'Hướng dẫn dinh dưỡng không thay thế tư vấn y tế cho chấn thương.',
  },
};

const resources = {
  en,
  vi,
};

Object.entries(
  resources,
).forEach(
  ([language, value]) => {
    i18n.addResourceBundle(
      language,
      'translation',
      value,
      true,
      true,
    );
  },
);

export default resources;
